'use client';
import React from 'react';

export default function ResetLayoutPanel({ panelState, setPanelState }) {
  return (
    <div>
      <h4>ResetLayout Panel</h4>
      <p>This is the ResetLayoutPanel component.</p>
    </div>
  );
}
