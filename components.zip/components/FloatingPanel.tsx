'use client';
import React, { useRef, useEffect, useState } from 'react';

const LS_PREFIX = 'abc-panel-';
const SNAP_DISTANCE = 64; // Snap sensitivity: more forgiving
const SNAP_DURATION = 240; // ms

function getSnapZones() {
  if (typeof window === "undefined") return [];
  return [
    { name: 'left',   x: 0, y: window.innerHeight/2, w: 48, h: window.innerHeight },
    { name: 'right',  x: window.innerWidth - 48, y: window.innerHeight/2, w: 48, h: window.innerHeight },
    { name: 'top',    x: window.innerWidth/2, y: 0, w: window.innerWidth, h: 48 },
    { name: 'bottom', x: window.innerWidth/2, y: window.innerHeight - 48, w: window.innerWidth, h: 48 },
  ];
}

function getClosestSnapZone(x: number, y: number) {
  const snapZones = getSnapZones();
  let minDist = Infinity, best = null;
  for (const zone of snapZones) {
    let zx = zone.x, zy = zone.y;
    if(zone.name === 'left' || zone.name === 'right') zy = y;
    if(zone.name === 'top' || zone.name === 'bottom') zx = x;
    const dist = Math.abs(zx - x) + Math.abs(zy - y);
    if (dist < minDist) { minDist = dist; best = zone; }
  }
  return minDist < SNAP_DISTANCE ? best : null;
}

function lerpColor(color1: string, color2: string, t: number) {
  function hex2rgb(h: string) {
    let r = parseInt(h.slice(1,3),16);
    let g = parseInt(h.slice(3,5),16);
    let b = parseInt(h.slice(5,7),16);
    return [r,g,b];
  }
  function rgb2hex([r,g,b]: number[]) {
    return "#" + [r,g,b].map(x=>x.toString(16).padStart(2,"0")).join("");
  }
  let c1 = hex2rgb(color1), c2 = hex2rgb(color2);
  let out = c1.map((v,i)=>Math.round(v*(1-t) + c2[i]*t));
  return rgb2hex(out as [number,number,number]);
}

const zCounter = { value: 10 };

export default function FloatingPanel({
  id,
  title,
  children,
  config = {}
}:{
  id: string,
  title?: string,
  children: React.ReactNode,
  config?: {
    alwaysDocked?: boolean,
    autoOpen?: boolean,
    disableResize?: boolean
  }
}) {
  const panelRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<[number, number]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = window.localStorage.getItem(LS_PREFIX + id + '-pos');
        if(saved) return JSON.parse(saved);
      } catch {}
    }
    return [Math.random()*400+40, Math.random()*200+40];
  });
  const [size, setSize] = useState<[number, number]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = window.localStorage.getItem(LS_PREFIX + id + '-size');
        if(saved) return JSON.parse(saved);
      } catch {}
    }
    return [360, 380];
  });
  const [z, setZ] = useState(zCounter.value++);
  const [drag, setDrag] = useState(false);
  const [dock, setDock] = useState<string|null>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [snapMode, setSnapMode] = useState(false);
  const [snapHighlight, setSnapHighlight] = useState<string|null>(null);
  const [snapFlash, setSnapFlash] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined')
      window.localStorage.setItem(LS_PREFIX + id + '-pos', JSON.stringify(pos));
  }, [pos]);
  useEffect(() => {
    if (typeof window !== 'undefined')
      window.localStorage.setItem(LS_PREFIX + id + '-size', JSON.stringify(size));
  }, [size]);
  useEffect(() => {
    if (typeof window !== 'undefined')
      window.localStorage.setItem(LS_PREFIX + id + '-dock', JSON.stringify(dock));
  }, [dock]);
  useEffect(() => {
    if (typeof window !== 'undefined')
      window.localStorage.setItem(LS_PREFIX + id + '-fullscreen', JSON.stringify(fullscreen));
  }, [fullscreen]);

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.ctrlKey) setSnapMode(true);
    }
    function onKeyUp(e: KeyboardEvent) {
      if (!e.ctrlKey) setSnapMode(false);
    }
    if (typeof window !== 'undefined') {
      window.addEventListener('keydown', onKeyDown);
      window.addEventListener('keyup', onKeyUp);
    }
    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('keydown', onKeyDown);
        window.removeEventListener('keyup', onKeyUp);
      }
    };
  }, []);

  function onMouseDown(e: React.MouseEvent) {
    if (e.button !== 0) return;
    setZ(zCounter.value++);
    setDrag(true);
    if (e.ctrlKey) setSnapMode(true);
    else setSnapMode(false);
    e.stopPropagation();
  }

  function onMouseMove(e: MouseEvent) {
    if (!drag) return;
    let nx = e.clientX - size[0]/2;
    let ny = e.clientY - 18;
    if(snapMode) {
      const zone = getClosestSnapZone(e.clientX, e.clientY);
      if (zone) setSnapHighlight(zone.name);
      else setSnapHighlight(null);
    } else {
      setSnapHighlight(null);
    }
    if(!snapMode) {
      setPos([nx, ny]);
      setDock(null);
    }
  }
  function onMouseUp(e: MouseEvent) {
    if (!drag) return;
    if (snapMode && snapHighlight) {
      setDock(snapHighlight);
      setSnapFlash(true);
      setTimeout(()=>setSnapFlash(false), SNAP_DURATION);
    } else if (!snapMode) {
      setPos([e.clientX - size[0]/2, e.clientY - 18]);
      setDock(null);
    }
    setDrag(false);
    setSnapMode(false);
    setSnapHighlight(null);
  }

  useEffect(() => {
    if (drag) {
      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', onMouseUp);
      document.body.style.userSelect = 'none';
    } else {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      document.body.style.userSelect = '';
    }
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      document.body.style.userSelect = '';
    };
  }, [drag, snapMode, snapHighlight, size, pos]);

  function onTitleDoubleClick() {
    setFullscreen(f=>!f);
    setDock(null);
  }

  let style: React.CSSProperties = {
    position: 'fixed',
    left: fullscreen ? 0 : dock === 'left' ? 0 : dock === 'right' ? (typeof window !== 'undefined' ? window.innerWidth - size[0] : 0) : pos[0],
    top: fullscreen ? 0 : dock === 'top' ? 0 : dock === 'bottom' ? (typeof window !== 'undefined' ? window.innerHeight - size[1] : 0) : pos[1],
    width: fullscreen ? '100vw' : size[0],
    height: fullscreen ? '100vh' : size[1],
    zIndex: z,
    borderRadius: 16,
    boxShadow: '0 8px 36px 4px rgba(0,0,0,0.14)',
    background: '#fff',
    transition: 'all 0.23s cubic-bezier(.85,0,.19,1.02)',
    border: '2px solid #eee',
    overflow: 'hidden',
    userSelect: drag ? 'none' : 'auto',
    cursor: drag ? (snapMode ? 'crosshair' : 'grabbing') : 'default'
  };

  function renderSnapZones() {
    if (!snapMode || typeof window === "undefined") return null;
    const snapZones = getSnapZones();
    return (
      <div style={{
        pointerEvents: 'none',
        position: 'fixed',
        top:0, left:0, width:'100vw', height:'100vh',
        zIndex: 999999999,
        mixBlendMode: 'screen',
      }}>
        {snapZones.map((zone, i) => {
          let isActive = snapHighlight === zone.name;
          let dist = 1;
          if(drag) {
            const mx = pos[0]+size[0]/2, my = pos[1]+24;
            let zx = zone.x, zy = zone.y;
            if(zone.name==='left'||zone.name==='right') zy = my;
            if(zone.name==='top'||zone.name==='bottom') zx = mx;
            const d = Math.abs(zx - mx) + Math.abs(zy - my);
            dist = Math.min(1, d / SNAP_DISTANCE);
          }
          let base = snapFlash && isActive ? '#ff2222' : lerpColor('#ffffff', '#ff2222', 1 - dist);
          let opacity = isActive ? 0.75 : 0.29 * (1 - dist) + 0.07;
          let shadow = `0 0 54px 24px ${base}`;
          let style: React.CSSProperties = {
            position: 'absolute',
            borderRadius: zone.name==='left'||zone.name==='right'? '32px 0 0 32px':'32px',
            boxShadow: shadow,
            opacity,
            background: base,
            pointerEvents: 'none',
            left: zone.name==='right'?undefined:zone.x-24,
            top: zone.name==='bottom'?undefined:zone.y-24,
            width: zone.name==='left'||zone.name==='right'?48:window.innerWidth,
            height: zone.name==='top'||zone.name==='bottom'?48:window.innerHeight,
            right: zone.name==='right'?0:undefined,
            bottom: zone.name==='bottom'?0:undefined,
            transition: 'background 0.12s, opacity 0.12s'
          };
          return <div key={zone.name} style={style} />;
        })}
      </div>
    );
  }

  return (
    <>
      {renderSnapZones()}
      <div
        ref={panelRef}
        style={style}
        onMouseDown={onMouseDown}
        tabIndex={0}
        className="abc-floating-panel"
      >
        <div
          style={{
            cursor: drag ? (snapMode ? 'crosshair' : 'grabbing') : 'grab',
            background: '#f6f6f7',
            borderBottom: '1.5px solid #eee',
            fontWeight: 700,
            fontSize: 18,
            padding: '8px 16px',
            userSelect: 'none',
            letterSpacing: 0.04,
          }}
          onDoubleClick={onTitleDoubleClick}
        >
          {title ?? id}
        </div>
        <div style={{
          width: '100%',
          height: 'calc(100% - 38px)',
          overflow: 'auto',
          background: '#fff'
        }}>
          {children}
        </div>
      </div>
    </>
  );
}
