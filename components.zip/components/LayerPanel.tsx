'use client';
import React from 'react';

export default function LayerPanel({ panelState, setPanelState }) {
  return (
    <div>
      <h4>Layer Panel</h4>
      <p>This is the LayerPanel component.</p>
    </div>
  );
}
