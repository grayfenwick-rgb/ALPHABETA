'use client';
import React from 'react';

export default function UndoRedoPanel({ panelState, setPanelState }) {
  return (
    <div>
      <h4>UndoRedo Panel</h4>
      <p>This is the UndoRedoPanel component.</p>
    </div>
  );
}
