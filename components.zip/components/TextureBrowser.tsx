'use client';
import React from 'react';

export default function TextureBrowser({ panelState, setPanelState }) {
  return (
    <div>
      <h4>TextureBrowser</h4>
      <p>This is the TextureBrowser component.</p>
    </div>
  );
}
