'use client';
import React from 'react';

export default function ToolsPanel({ panelState, setPanelState }) {
  return (
    <div>
      <h4>Tools Panel</h4>
      <p>This is the ToolsPanel component.</p>
    </div>
  );
}
