'use client';
import React from 'react';

export default function Keyboard({ panelState, setPanelState }) {
  return (
    <div>
      <h4>Keyboard</h4>
      <p>This is the Keyboard component.</p>
    </div>
  );
}
