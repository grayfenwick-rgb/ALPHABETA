import { useThree } from '@react-three/fiber';
import { useEffect } from 'react';

export function ParallaxCamera() {
  const { camera } = useThree();

  useEffect(() => {
    function handleMouse(e: MouseEvent) {
      const x = (e.clientX / window.innerWidth) * 2 - 1;
      const y = (e.clientY / window.innerHeight) * 2 - 1;
      // Tweak these numbers for more/less movement
      camera.position.x = x * 0.4;
      camera.position.y = -y * 0.2;
      camera.lookAt(0, 0, 0);
    }
    window.addEventListener('mousemove', handleMouse);
    return () => window.removeEventListener('mousemove', handleMouse);
  }, [camera]);

  return null;
}