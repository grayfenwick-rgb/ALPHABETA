'use client';
import React from 'react';

export default function ThreeViewer({ panelState, setPanelState }) {
  return (
    <div>
      <h4>ThreeViewer</h4>
      <p>This is the ThreeViewer component.</p>
    </div>
  );
}
