'use client';
import React from 'react';
import FloatingPanel from './FloatingPanel';
import DeskCovers from './DeskCovers';
import ToolsPanel from './ToolsPanel';
import LayerPanel from './LayerPanel';
import ThreeViewer from './ThreeViewer';
import TextureBrowser from './TextureBrowser';
import UndoRedoPanel from './UndoRedoPanel';
import ExportPanel from './ExportPanel';
import PresetPanel from './PresetPanel';
import StyleSelector from './StyleSelector';
import Keyboard from './Keyboard';
import ResetLayoutPanel from './ResetLayoutPanel';
import ThreeDesk from './ThreeDesk';

export default function WorkspaceStudio() {
  return (
    <div style={{ width: '100vw', height: '100vh', background: '#1a1a1a', overflow: 'hidden' }}>
      <ThreeDesk />
      <FloatingPanel id="ToolsPanel" title="Tools Panel" allowFullscreen={true} defaultPos={{ x: 100, y: 60 }}>
        <ToolsPanel />
      </FloatingPanel>
      <FloatingPanel id="LayerPanel" title="Layer Panel" allowFullscreen={false} defaultPos={{ x: 320, y: 60 }}>
        <LayerPanel />
      </FloatingPanel>
      <FloatingPanel id="ThreeViewer" title="Three Viewer" allowFullscreen={true} defaultPos={{ x: 540, y: 60 }}>
        <ThreeViewer />
      </FloatingPanel>
      <FloatingPanel id="TextureBrowser" title="Texture Browser" allowFullscreen={true} defaultPos={{ x: 760, y: 60 }}>
        <TextureBrowser />
      </FloatingPanel>
      <FloatingPanel id="UndoRedoPanel" title="Undo Redo Panel" allowFullscreen={false} defaultPos={{ x: 980, y: 60 }}>
        <UndoRedoPanel />
      </FloatingPanel>
      <FloatingPanel id="ExportPanel" title="Export Panel" allowFullscreen={false} defaultPos={{ x: 100, y: 300 }}>
        <ExportPanel />
      </FloatingPanel>
      <FloatingPanel id="PresetPanel" title="Preset Panel" allowFullscreen={false} defaultPos={{ x: 320, y: 300 }}>
        <PresetPanel />
      </FloatingPanel>
      <FloatingPanel id="StyleSelector" title="Style Selector" allowFullscreen={true} defaultPos={{ x: 540, y: 300 }}>
        <StyleSelector />
      </FloatingPanel>
      <FloatingPanel id="Keyboard" title="Keyboard" allowFullscreen={false} defaultPos={{ x: 760, y: 300 }}>
        <Keyboard />
      </FloatingPanel>
      <FloatingPanel id="ResetLayoutPanel" title="Reset Layout Panel" allowFullscreen={false} defaultPos={{ x: 980, y: 300 }}>
        <ResetLayoutPanel />
      </FloatingPanel>
      <DeskCovers />
    </div>
  );
}
