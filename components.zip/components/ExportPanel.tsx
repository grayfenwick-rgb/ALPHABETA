'use client';
import React from 'react';

export default function ExportPanel({ panelState, setPanelState }) {
  return (
    <div>
      <h4>Export Panel</h4>
      <p>This is the ExportPanel component.</p>
    </div>
  );
}
